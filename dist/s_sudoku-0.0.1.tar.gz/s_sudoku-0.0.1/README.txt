This a very simple sudoku solver.

You can call function
print_board(board) to print the board
board = solver(board) to get the solved board
